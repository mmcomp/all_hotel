<?php
	session_start();
	include("../kernel.php");
        if(!isset($_SESSION['user_id']))
                die(lang_fa_class::access_deny);
        $se = security_class::auth((int)$_SESSION['user_id']);
        //if(!$se->can_view)
              //  die(lang_fa_class::access_deny);
	$shart_1 = '';
	$sabtShod = '';
	$hotel_acc = daftar_class::HotelList((int)$_SESSION['daftar_id']);
	$shart = '';
	if($hotel_acc!=null)
	{
		if (count($hotel_acc)==1)
			$_REQUEST["hotel_id_new"] = $hotel_acc[0];
		for($l=0;$l<count($hotel_acc);$l++)
			$shart.=(($l == 0) ? '  (' : ',').$hotel_acc[$l].(($l==count($hotel_acc)-1)?')':'');
		$shart_1 = "where `id` in ".$shart;
	}
////////////////////
	if (isset($_REQUEST["mod"]))
                $mod = $_REQUEST["mod"];
	else
		$mod = -1;
	if (isset($_REQUEST["hotel_id_new"]))
                $hotel_id_new = $_REQUEST["hotel_id_new"];
	else
		$hotel_id_new = -1;
	if (isset($_REQUEST["sms_typ"]))
                $sms_typ = $_REQUEST["sms_typ"];
	else
		$sms_typ = -1;
	if (isset($_REQUEST["def_matn"]))
		$def_matn = $_REQUEST["def_matn"];
	else
		$def_matn = -1;
	if (isset($_REQUEST["save_sms"]))
                $save_sms = $_REQUEST["save_sms"];
	else
		$save_sms = -1;
	if (isset($_REQUEST["del_sms"]))
		$del_sms = $_REQUEST["del_sms"];
	else
		$del_sms= -1;
	if (($hotel_id_new != -1)&&($sms_typ != -1))
	{
		mysql_class::ex_sqlx("insert into `mehman_sms` (`id`, `matn`, `typ`, `hotel_id`) values (NULL, '$def_matn', '$sms_typ', '$hotel_id_new')");
		$sabtShod = "پیامک جدید ثبت شد";
	}
	$combo_hotel = "";
	$combo_hotel .= "<select class='inp' id=\"hotel_id\" name=\"hotel_id_new\" style=\"width:auto;\">\n<option value=\"-1\">\n&nbsp\n</option>\n";
	mysql_class::ex_sql("select * from `hotel` $shart_1 order by `name`",$q);
	while($r = mysql_fetch_array($q))
	{
		if((int)$r["id"]== (int)$hotel_id_new)
	        {
	                $select = "selected='selected'";
	        }
	        else
	        {
	                $select = "";
	        }
	        $combo_hotel .= "<option value=\"".(int)$r["id"]."\" $select   >\n";
	        $combo_hotel .= $r["name"]."\n";
	        $combo_hotel .= "</option>\n";
	}
	$combo_hotel .= "</select>";
	$combo_typ = '';
	$combo_typ .= "<select class='inp' id=\"sms_typ\" name=\"sms_typ\" style=\"width:auto;\">\n<option value=\"-1\">\n&nbsp\n</option>\n";
	mysql_class::ex_sql("select * from `sms_typ`order by `typ`",$q);
	while($r = mysql_fetch_array($q))
	{
		if((int)$r["id"]== (int)$sms_typ)
	        {
	                $select = "selected='selected'";
	        }
	        else
	        {
	                $select = "";
	        }
	        $combo_typ .= "<option value=\"".(int)$r["id"]."\" $select   >\n";
	        $combo_typ .= $r["typ"]."\n";
	        $combo_typ .= "</option>\n";
	}
	$combo_typ .= "</select>";
	$matns = '';
	if (isset($_REQUEST['mod']))
	{
		foreach($_REQUEST as $name)
		{
			$matns .= $name.',';
		}
		$re = explode(",",$matns);
		$id = $re[0];
		$typ = $re[1];
		$matn_sms = $re[2];
		if (($id!='')&&($typ!='')&&($matn_sms!='')&&($save_sms==1))
		{
			mysql_class::ex_sqlx("update `mehman_sms` SET `matn` = '$matn_sms' WHERE `id` ='$id'");
			$sabtShod = "متن پیامک با موفقیت تغییر یافت";
		}
		elseif(($id!='')&&($typ!='')&&($matn_sms!='')&&($del_sms==2))
		{
			mysql_class::ex_sqlx("delete from `mehman_sms` where `id` = '$id'");
			$sabtShod = "پیامک مورد نظر حذف شد";
		}
		else
			$sabtShod = "";	
		
	}
	if (isset($_REQUEST['new_rec']))
	{
		foreach($_REQUEST as $name)
		{
			$matns .= $name.',';
		}
		$re = explode(",",$matns);
		$id = $re[0];
		$typ = $re[1];
		$matn_sms = $re[2];
		if (($id!='')&&($typ!='')&&($matn_sms!=''))
		{
			mysql_class::ex_sqlx("update `mehman_sms` SET `matn` = '$matn_sms' WHERE `id` ='$id'");
		}
	}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link type="text/css" href="../css/style.css" rel="stylesheet" />

		<link type="text/css" href="../js/styles/jquery-ui-1.8.14.css" rel="stylesheet" />
		<script type="text/javascript" src="../js/jquery/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="../js/jquery/jquery.ui.datepicker-cc.all.min.js"></script>
		<script type="text/javascript" src="../js/tavanir.js"></script>
		<script type="text/javascript">
		function send_search()
		{
			if(trim(document.getElementById('matn').value)=='')
				alert('متن  پیامک وارد نشده است');
			else
				document.getElementById('frm1').submit();
		}
		function set_value(inp)
		{
			document.getElementById('mablagh').value = document.getElementById(inp).innerHTML;
		}
		function processEnter(input)
		{
		    var enterCount = 0;
		    for (var i = 0; i < input.length; i++)
		    {
			if (input.charCodeAt(i) == 10)
			{
			    enterCount ++;
			}
		    }
		    return enterCount;
		}
		function isEnglishString(input )
		{
		    if (input == '')
		    {
			return true;
		    }
		    
		    for (var i = 0; i < input.length; i++)
		    {
			if (input.charCodeAt(i) > 127)
			{   
			    return false;
			}
		    }
		    return true;
		}

		function updateLengthAndMessageCount2(MainTextFieldName, messageLengthFieldName, messageCountFieldName, fieldmobileCount)
		{
		    var fieldObj = document.getElementById(MainTextFieldName);
		    var messageLengthField = document.getElementById(messageLengthFieldName);
		    var messageCountField = document.getElementById(messageCountFieldName);
		    var messageContent1 = fieldObj.value;
		    var messageContent = messageContent1.replace(/(\r\n|\r|\n)/g, ' ');
		    
		    var enterCount = processEnter(messageContent);
		    var browserName = navigator.appName;
		    var messageLength = messageContent.length + fieldmobileCount;

		       
		       if (browserName != 'Netscape')
		 	{
				messageLength = messageLength - enterCount;
		    	}

		    var RemainLength = 0;

		    var maxMessageCount = 4;
		    var maxEnglishLength = 160;
		    var maxPersianLength = 70;
		    var maxLongEnglishLength = 153;
		    var maxLongPersianLength = 63;
		    var isEnMessage = isEnglishString(messageContent);
		    
		    var maxMessageLength = isEnMessage ? (maxMessageCount * maxLongEnglishLength) : (maxMessageCount * maxLongPersianLength);
		    fieldObj.MaxLength = maxMessageLength;

		    var messageCount = 1;

		    if (isEnMessage && messageLength > maxEnglishLength)
		    {
			messageCount = messageLength > maxMessageLength ?
				       maxMessageCount : parseInt(messageLength % maxLongEnglishLength) == 0 ?
				                         parseInt(messageLength / maxLongEnglishLength) :
				                         parseInt(messageLength / maxLongEnglishLength) + 1;
		    }
		    
		    if (!isEnMessage && messageLength > maxPersianLength)
		    {
			messageCount = messageLength > maxMessageLength ?
				       maxMessageCount : parseInt(messageLength % maxLongPersianLength) == 0 ?
				                         parseInt(messageLength / maxLongPersianLength) :
				                         parseInt(messageLength / maxLongPersianLength) + 1;

		    }
		    
		    if (messageCount == 1) 
		    {
		    RemainLength = isEnMessage ?  parseInt(maxEnglishLength - messageLength) : parseInt( maxPersianLength - messageLength)
		    
		    }
		    else
		    {
		    RemainLength = isEnMessage ?  parseInt(messageCount * maxLongEnglishLength - messageLength) : parseInt( messageCount * maxLongPersianLength - messageLength)
		   
		    }
		    messageLengthField.value =  RemainLength;
		    messageCountField.value = messageCount;

		}
		</script>
		<script type="text/javascript">
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#datepicker6").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#datepicker7").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
			function showInsert_typ()
			{
				 document.getElementById("insert_typ").style.display="block";
			}
			function del()
			{
				document.getElementById('mod').value = '2';
				document.getElementById("frm1").submit();
			}
	    	</script>
		<style type="text/css" >
			td{text-align:center;}
		</style>
		<title>
		تعریف متن پیامک
		</title>
	</head>
	<body>
		<?php echo security_class::blockIfBlocked($se,lang_fa_class::block); ?>
		<div align="center">
			<br/>
				<h3><?php echo $sabtShod;?></h3>
			<br/>	
			<table cellpadding="0" cellspacing="0" width="95%" style="border-style:solid;border-width:1px;border-color:Black;font-size:13px;">
				<tr class="showgrid_header" >
					<th>ردیف</th>
					<th>هتل</th>
					<th>نوع</th>
					<th>متن پیامک </th>
					<th> </th>
					<th> </th>
				</tr>		
			<?php
				mysql_class::ex_sql("select * from `mehman_sms`",$q);
				$i = 1;
				$noe = '';
				while($r=mysql_fetch_array($q))
				{
					$row_style = 'class="showgrid_row_odd"';
					$matn = $r['matn'];
					$noe_sms = $r['typ'];
					$hotel_id = $r['hotel_id'];
					mysql_class::ex_sql("select * from `sms_typ` where `id`='$noe_sms'",$q_sms);
					if($r_sms=mysql_fetch_array($q_sms))
						$noe = $r_sms['typ'];
					mysql_class::ex_sql("select * from `hotel` where `id`='$hotel_id'",$q_hotel);
					if($r_hotel=mysql_fetch_array($q_hotel))
						$hotel_name = $r_hotel['name'];
					else
						$hotel_name = "";
					if($i%2==0)
						$row_style = 'class="showgrid_row_even"';
					$matn_name = "matn_".$i;
					$f_name = "frm1_".$i;
			?>
			<form id="<?php echo $f_name;?>"  method='GET' >		
				<tr <?php echo $row_style;?>>
					<td valign="center" ><?php echo $i;?></td>
					<td valign="center" ><?php echo $hotel_name;?></td>
					<td valign="center" ><?php echo $noe;?></td>
					<td valign="top" >
						<input type='hidden' name="id_sms_<?php echo $i;?>" id="id_sms_<?php echo $i;?>" value="<?php echo $r['id'];?>" >
						<input type='hidden' name="typ_sms_<?php echo $i;?>" id="typ_sms_<?php echo $i;?>" value="<?php echo $noe_sms;?>" >
						<textarea onkeyup="updateLengthAndMessageCount2('matn_<?php echo $i;?>','harf_<?php echo $i;?>','tedad_<?php echo $i;?>',1)" name="<?php echo $matn_name;?>" id="<?php echo $matn_name;?>" rows="5" cols="30" style="font-family:tahoma;font-size:12px;" ><?php echo $matn; ?></textarea>
					</td>
					<td valign="center" >
						تعداد پیامک:
						<input style="width:30px;" value="<?php echo ((isset($_REQUEST['tedad']))?$_REQUEST['tedad']:''); ?>" id="tedad_<?php echo $i;?>" name="tedad_<?php echo $i;?>" class="inp" readonly="readonly" >
												حروف:
						<input  style="width:50px;" value="<?php echo ((isset($_REQUEST['harf']))?$_REQUEST['harf']:''); ?>" id="harf_<?php echo $i;?>" name="harf_<?php echo $i;?>" class="inp" readonly="readonly" >
					</td>
					<td>
						<input type="radio" name="save_sms" value="1">ذخیره
						<input type="radio" name="del_sms" value="2">حذف
						<input type='hidden' name='mod' id='mod' value='1' >
						<input type="submit" value="ارسال تغییرات" class="inp"/>		
					</td>
				</tr>
			</form>
			<?php 
				$i++;
				}
			?>
			</table>
			<br/>
			<center>
				 				
				<div id='insert_typ'>
					<form name="input" action="tarif_sms.php" method="post">
						<table border="1" cellpadding="0" cellspacing="0" width="95%" style="font-size:12px;border-style:solid;border-width:1px;border-color:Black;margin:10px;" >
							<tr class="showgrid_header" >
								<th>نام هتل</th>
								<th>نوع پیامک</th>
								<th>متن پیش فرض</th>
							</tr>
							<tr class="showgrid_row_odd" >
								<td><?php echo $combo_hotel;?></td>
								<td><?php echo $combo_typ;?></td>
								<td><input type='text' name='def_matn' id='def_matn'></td>
							</tr>
						</table>
						<input type="submit" value="ثبت نوع پیامک جدید">
					</form>
				</div>
			</center>
		</div>
	</body>
</html>
