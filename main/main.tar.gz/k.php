<?php
	include('../kernel.php');
	var_dump(reserve_class::isPaziresh(667,72));
?>
