                        $hotel = new hotel_class((int)$hotel_id);
                        $h_moeen = new moeen_class($hotel->moeen_id);
                        $ajans = new ajans_class((int)$ajans_id);
                        $a_moeen = new moeen_class($ajans->moeen_id);
