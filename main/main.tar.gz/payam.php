<?php
	session_start();
	include("../kernel.php");
        if(!isset($_SESSION['user_id']))
                die(lang_fa_class::access_deny);
        $se = security_class::auth((int)$_SESSION['user_id']);
        if(!$se->can_view)
                die(lang_fa_class::access_deny);	
	if (isset($_REQUEST["group_id_new"]))
                $group_id_new = $_REQUEST["group_id_new"];
	else
		$group_id_new = -1;
	if (isset($_REQUEST["users_id"]))
                $users_id = $_REQUEST["users_id"];
	else
		$users_id = -1;
	$_SESSION['grop'] = $group_id_new;
	$log_user_id = $_SESSION["user_id"];
	$showPayam = FALSE;
	mysql_class::ex_sql("select `id` from `payam` where `rec_user_id`='$log_user_id' and `en`='-1'",$q_payam);
	while ($r_payam = mysql_fetch_array($q_payam))
	{
		$id = $r_payam['id'];
		mysql_class::ex_sqlx("update `payam` set `en`='1' where `id` = $id");
	}
	function loadUser($user_id)
	{
		$out = "";
		mysql_class::ex_sql("select `fname` , `lname` from `user` where `id`='$user_id'",$q);
		if($r = mysql_fetch_array($q))
			$out = $r['fname'].' '.$r['lname'];
		return $out;
	}
	function hamed_pdate($str)
        {
                $out=jdate('Y/n/j',strtotime($str));
                return $out;
        }
	function loadPayam($inp)
        {
                $out = '';
		mysql_class::ex_sql("select * from `payam_toz` where `id`='$inp'",$q);
		if($r = mysql_fetch_array($q))
			$out= $r['toz'];
		return($out);
        }
	$combo_group = "";
	$combo_group.= "<form name=\"selGroup\" id=\"selGroup\" method=\"POST\">";
		$combo_group .= "<select class='inp' id=\"group_id\" name=\"group_id_new\" onchange=\"document.getElementById('selGroup').submit();\" style=\"width:auto;\">\n<option value=\"-1\">\nهمه\n</option>\n";
		mysql_class::ex_sql("select * from `grop` where `en`>0 order by `name`",$q);
		while($r = mysql_fetch_array($q))
		{
			if((int)$r["id"]== (int)$group_id_new)
		        {
		                $select = "selected='selected'";
		        }
		        else
		        {
		                $select = "";
		        }
		        $combo_group .= "<option value=\"".(int)$r["id"]."\" $select   >\n";
		        $combo_group .= $r["name"]."\n";
		        $combo_group .= "</option>\n";
		}
		$combo_group .= "</select>";
	$combo_group .= "</form>";	
	$combo_user = "";
	$combo_user .= "<form name=\"selUser\" id=\"selUser\" method=\"POST\">";
		$combo_user .= "<select class='inp' id=\"users_id\" name=\"users_id\" onchange=\"document.getElementById('selUser').submit();\" style=\"width:auto;\">\n<option value=\"-1\">\nهمه\n</option>\n";
		if ($group_id_new==-1)
			mysql_class::ex_sql("select `id`,`fname`,`lname` from `user` order by `lname`",$q);
		else
			mysql_class::ex_sql("select `id`,`fname`,`lname` from `user` where `typ`='$group_id_new' order by `lname`",$q);
		while($r = mysql_fetch_array($q))
		{
			if((int)$r["id"]== (int)$users_id)
		        {
		                $select = "selected='selected'";
		        }
		        else
		        {
		                $select = "";
		        }
		        $combo_user .= "<option value=\"".(int)$r["id"]."\" $select   >\n";
		        $combo_user .= $r["lname"]."\n";
		        $combo_user .= "</option>\n";
		}
		$combo_user .= "</select>";
		$combo_user .= '<input type="hidden" name="group_id_new" value="'.$group_id_new.'" >';
	$combo_user .= "</form>";
	$user_id = (int)$_SESSION['user_id'];
	if (isset($_REQUEST['matn_payam']))
	{
		$tarikh_now = date("Y-m-d");
		$payam_group = $_REQUEST['group_id_new'];
		$payam_user = $_REQUEST['users_id'];
		$matn_payam = $_REQUEST['matn_payam'];
		if (($payam_group==-1)&&($payam_user==-1))
		{
			$ln = mysql_class::ex_sqlx("insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')",FALSE);
			$payam_id = mysql_insert_id($ln);
			mysql_close($ln);
			$query = "insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')";
			mysql_class::ex_sql("select `id` from `user`",$q);
			while($r = mysql_fetch_array($q))
			{
				$rec_id = $r['id'];
				mysql_class::ex_sqlx("insert into `payam` (`id`, `se_user_id`, `rec_user_id`, `payam_id`,`tarikh`,`en`) values (NULL, '$user_id', '$rec_id', '$payam_id','$tarikh_now','-1')");
			}
		}
		elseif (($payam_group==-1)&&($payam_user!=-1))
		{
			$ln = mysql_class::ex_sqlx("insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')",FALSE);
			$payam_id = mysql_insert_id($ln);
			mysql_close($ln);
			mysql_class::ex_sqlx("insert into `payam` (`id`, `se_user_id`, `rec_user_id`, `payam_id`,`tarikh`,`en`) values (NULL, '$user_id', '$payam_user', '$payam_id','$tarikh_now','-1')");
		}
		elseif (($payam_group!=-1)&&($payam_user==-1))
		{
			$ln = mysql_class::ex_sqlx("insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')",FALSE);
			$payam_id = mysql_insert_id($ln);
			mysql_close($ln);
			$query = "insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')";
			mysql_class::ex_sql("select `id` from `user` where `typ`='$payam_group'",$q);
			while($r = mysql_fetch_array($q))
			{
				$rec_id = $r['id'];
				mysql_class::ex_sqlx("insert into `payam` (`id`, `se_user_id`, `rec_user_id`, `payam_id`,`tarikh`,`en`) values (NULL, '$user_id', '$rec_id', '$payam_id','$tarikh_now','-1')");
			}
		}
		elseif (($payam_group!=-1)&&($payam_user!=-1))
		{
			$ln = mysql_class::ex_sqlx("insert into `payam_toz` (`id`, `toz`) values (NULL, '$matn_payam')",FALSE);
			$payam_id = mysql_insert_id($ln);
			mysql_close($ln);
			mysql_class::ex_sqlx("insert into `payam` (`id`, `se_user_id`, `rec_user_id`, `payam_id`,`tarikh`,`en`) values (NULL, '$user_id', '$payam_user', '$payam_id','$tarikh_now','-1')");
		}
		else
			echo '';
	}	
	if ($se->detailAuth('admin'))
		$shart = "1=1 order by `tarikh` DESC, `payam_id` DESC";
	else		
		$shart = "(`se_user_id`='$user_id' or `rec_user_id`='$user_id') order by `tarikh` DESC, `payam_id` DESC";
	$grid = new jshowGrid_new("payam","grid1");
	$grid->whereClause= $shart;
	$grid->columnHeaders[0]= null;
	$grid->columnHeaders[1]= 'ارسال کننده پیام';
	$grid->columnFunctions[1] = 'loadUser';
	$grid->columnHeaders[2]= 'دریافت کننده پیام';
	$grid->columnFunctions[2] = 'loadUser';
	$grid->columnHeaders[3]= 'متن پیام';
	$grid->columnFunctions[3] = 'loadPayam';
	$grid->columnHeaders[4]= 'تاریخ';
	$grid->columnFunctions[4] = 'hamed_pdate';
	$grid->columnHeaders[5]= null;
	$grid->canAdd = FALSE;
	$grid->canEdit = FALSE;
	$grid->canDelete = FALSE;
	$grid->intial();
	$grid->executeQuery();
	$out = $grid->getGrid();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link type="text/css" href="../css/style.css" rel="stylesheet" />

		<link type="text/css" href="../js/styles/jquery-ui-1.8.14.css" rel="stylesheet" />
		<script type="text/javascript" src="../js/jquery/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="../js/jquery/jquery.ui.datepicker-cc.all.min.js"></script>
		<script type="text/javascript" src="../js/tavanir.js"></script>
		<script>
			$(document).ready(function(){
				$("#new_user_id").hide();
				$("#new_rec_grop").hide();
				$("#new_user_pasokh").hide();
				$("#new_toz_pasokh").hide();
				$("#new_en").hide();
			});
		</script>
		<style>
			td{text-align:center;}
		</style>
		<title>
			پیام های ثبت شده	
		</title>
	</head>
	<body>
		<br/>
		<br/>
                <?php echo security_class::blockIfBlocked($se,lang_fa_class::block); ?>
		
		<br/>
		<table cellpadding="0" cellspacing="0" width="95%" style="border-style:solid;border-width:1px;border-color:Black;font-size:13px;">
				<tr class="showgrid_header" >
					<th>گروه کاربری</th>
					<th>کاربر</th>
					<th>متن پیامک </th>
					<th></th>
				</tr>	
					
				<tr class="showgrid_row_odd">
					<td valign="center" ><?php echo $combo_group;?></td>
					<td valign="center" ><?php echo $combo_user;?></td>
					<form id="payam_frm"  method='POST' >
						<td valign="top" >
							<textarea name="matn_payam" id="matn_payam" rows="5" cols="30" style="font-family:tahoma;font-size:12px;" ></textarea>
						</td>
						<input type='hidden' name="group_id_new" id="hi_group_id" value="<?php echo $group_id_new;?>" >
						<input type='hidden' name="users_id" id="hi_users_id" value="<?php echo $users_id;?>" >
						<td><input type="submit" value="ارسال پیام" class="inp"/></td>						
					</form>
				</tr>
			</table>
			<div align="center">
			<?php echo '<br/>'.$out; ?>
		</div>
	</body>
</html>
