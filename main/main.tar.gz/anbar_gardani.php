<?php	session_start();
	include_once("../kernel.php");
	if(!isset($_SESSION['user_id']))
                die(lang_fa_class::access_deny);
        $se = security_class::auth((int)$_SESSION['user_id']);
        if(!$se->can_view || !$conf->anbar )
                die(lang_fa_class::access_deny);
	function loadKala($inp)
	{
		$out = null;
		$out = new kala_class($inp);
		$out = $out->name.'('.$out->code.')';
		return($out);
	}
	function loadMojoodi($inp)
	{
		$moj = anbar_det_class::getMojoodi($inp);
		return audit_class::enToPer($moj['out']);
	}
	function loadAnbardarUsers()
	{
		$out ='<select name="anbardar_user" id="anbardar_user" class="inp" >' ;
		mysql_class::ex_sql("select `id`,`fname`,`lname` from `user` where `typ` in (select `id` from `grop` where `name` like '%انبار%') ",$q);
		while($r = mysql_fetch_array($q))
			$out .='<option value="'.$r['id'].'" >'.$r['fname'].' '.$r['lname']."</option>\n";
		$out .='</select>';
		return $out;
	}
	mysql_class::ex_sql("select `id`,`fname`,`lname` from `user` where `typ` in (select `id` from `grop` where `name` like '%انبار%') ",$qanbar);
	if(mysql_num_rows($qanbar)<=0)
		die('<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<link type="text/css" href="../css/style.css" rel="stylesheet" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	</head>
	<body>
		<center><h2>کابر انبار دار تعریف نشده است</h2></center>
	<body>
	</html>
');
	$anbar_id = (isset($_REQUEST['anbar_id']))?(int)$_REQUEST['anbar_id']:-1;
	$msg = '';
	$isGardani = FALSE;
	$user_id = (int)$_SESSION['user_id'];
	if(isset($_POST['calc']) && $_POST['calc']=='sabt' )
	{
		$anbar_user_id = $_POST['anbardar_user_id'];
		$kala_ids = kala_class::anbarGardaniArray($anbar_id);
		if($kala_ids!=null)
			$isGardani = anbar_det_gardani_class::sabtKalaGardani($kala_ids,$anbar_id,$anbar_user_id,$user_id);
		if($isGardani)
			$msg = "محاسبه حساب انبار دار انجام گردید";
	}
	/*
	var_dump($_REQUEST);
	$anbar_id = (isset($_REQUEST['anbar_id']))?(int)$_REQUEST['anbar_id']:-1;
	$out = '<form id="frm1" ><table cellpadding="0" cellspacing="0" width="95%" style="border-style:solid;border-width:1px;border-color:Black;"><tr class="showgrid_header" ><th>ردیف</th><th>نام کالا</th><th> موجودی سیستم</th><th>موجودی واقعی</th></tr>';
	mysql_class::ex_sql("select `kala_id` from `anbar_det` where `anbar_id`=$anbar_id ",$q);
	$i = 1;
	while($r = mysql_fetch_array($q))
	{
		$row_style = 'class="showgrid_row_odd"';
		if($i%2==0)
			$row_style = 'class="showgrid_row_even"';
		$kala_mojoodi = anbar_det_class::getMojoodi($r['kala_id']);
		$out.="<tr $row_style ><td>$i</td><td>".loadKala($r['kala_id'])."<input type='hidden' name='kala_id[]'  value='".$r['kala_id']."' ></td><td>".$kala_mojoodi['out']."<input type='hidden' name='mojoodi[]'  value='".$kala_mojoodi['out']."' ></td><td><input type='text' name='mojoodi_new[]'  class='inp' style='width:100px;' ></td></tr>";
		$i++;
	}
	$out .='<tr><td colspan="4" ><input class="inp" type="submit" value="محاسبه بدهکاری انبار دار"></td></tr>';
	$out .='</table></form>';
	*/
	$grid = new jshowGrid_new("kala","grid1");
	$mojood_kala = new anbar_class($anbar_id);
	$mojood_kala = $mojood_kala->loadKala();
	$grid->whereClause = " `id` in ($mojood_kala)";
	$grid->columnHeaders[0] = null;
       	$grid->columnHeaders[1] ='نام' ;
	$grid->columnHeaders[2] = "کد";
	$grid->columnHeaders[3] = null;
	$grid->columnHeaders[4] = null;
	$grid->columnHeaders[5] = 'موجودی واقعی';
	$grid->addFeild('id');
	$grid->columnHeaders[6] = 'موجودی سیستم';
	$grid->columnFunctions[6] = 'loadMojoodi';
	$grid->footer = '
<tr class="showgrid_row_odd" ><td colspan="5" >
کاربر انباردار:'.loadAnbardarUsers().'
<input class="inp" type="button" value="محاسبه بدهکاری انبار دار" onclick="submit_frm();" >
</td></tr>
';
	$grid->sortEnabled = TRUE;
	$grid->canAdd = FALSE;
	$grid->canDelete = FALSE;
        $grid->intial();
   	$grid->executeQuery();
        $out = $grid->getGrid();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<script type="text/javascript" src="../js/tavanir.js"></script>
		<link type="text/css" href="../css/style.css" rel="stylesheet" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>
انبار گردانی
		</title>
		<style>
			td{text-align:center;border:1px solid;padding:2px;}
		</style>
		<script>
			function submit_frm()
			{
				document.getElementById('anbardar_user_id').value = document.getElementById('anbardar_user').options[document.getElementById('anbardar_user').selectedIndex].value;
				//alert(document.getElementById('anbardar_user_id').value);
				document.getElementById('calc').value = 'sabt';
				document.getElementById('frm1').submit();
			}
		</script>
	</head>
	<body>
		<?php echo security_class::blockIfBlocked($se,lang_fa_class::block); ?>
		<div align="center">
			<?php echo $msg; ?>
			<br />
			<?php echo $out; ?>
			<form id="frm1" method="POST">
				<input type="hidden" name="calc" id="calc" >
				<input type="hidden" name="anbardar_user_id" id="anbardar_user_id" >
			</form>
		</div>
	</body>

</html>
