<?php	session_start();
	include_once("../kernel.php");
	if(!isset($_SESSION['user_id']))
                die(lang_fa_class::access_deny);
        $se = security_class::auth((int)$_SESSION['user_id']);
        if(!$se->can_view)
                die(lang_fa_class::access_deny);
	/*
	function loadMoeen($inp)
        {
                $inp = (int)$inp;
                $aj = new anbar_factor_class($inp);
                if($aj->moeen_id>0)
                {
                        $moeen = new moeen_class($aj->moeen_id);
                        $nama = $moeen->name.'('.$moeen->code.')';
                }
                else
                {
                        $nama = 'انتخاب';
                }
                $out = "<u><span onclick=\"window.location =('select_hesab.php?refPage=factor_kala.php?anbar_typ_id=".$_REQUEST['anbar_typ_id']."&sel_id=$inp');\"  style='color:blue;cursor:pointer;' >$nama</span></u>";
                return $out;
        }
	*/
	function loadMoeen()
	{
		$out = array();
		mysql_class::ex_sql("select `id`,`name` from `moeen` order by `name` ",$q);
		while($r = mysql_fetch_array($q))
			$out[(int)$r['id']]=$r['name'];
		return $out;
	}
	function add_item()
        {
                $fields = null;
                foreach($_REQUEST as $key => $value)
                {
                        if(substr($key,0,4)=="new_")
                        {
                                if($key != "new_id")
                                {
                                        $fields[substr($key,4)] = perToEnNums($value);
                                }
                        }
                }
		if(isset($_REQUEST['anbar_typ_id']) && $_REQUEST['anbar_typ_id']>0)
		{
			$fields["anbar_typ_id"] = $_REQUEST['anbar_typ_id'];
			$fields["user_id"] = (int)$_SESSION['user_id'];
			$fields['tarikh_resid'] = audit_class::hamed_pdateBack(perToEnNums($fields['tarikh_resid']));
		        $fi = "(";
		        $valu="(";
		        foreach ($fields as $field => $value)
		        {
		                $fi.="`$field`,";
		                $valu .="'$value',";
		        }
		        $fi=substr($fi,0,-1);
		        $valu=substr($valu,0,-1);
		        $fi.=")";
		        $valu.=")";
		        $query="insert into `anbar_factor` $fi values $valu";
		        mysql_class::ex_sqlx($query);
		}
		else
			echo 'نوع ورودی یا خروجی به انبار انتخاب نشده است';
        }
	function hpdate($inp)
	{
		return(audit_class::hamed_pdate($inp));
	}
	function hpdateback($inp)
	{
		return(audit_class::hamed_pdateBack(perToEnNums($inp)));
	}
	function delete_item($id)
	{
		mysql_class::ex_sqlx("update `anbar` set `en`=0 where `id` = $id");
	}
	function loadUser($inp)
	{
		$out = new user_class($inp);
		return $out->fname.' '.$out->lname;
	}
	function loadDet($inp)
        {
		$out = "";
		$anbar_fc = new anbar_factor_class($inp);
		if($anbar_fc->moeen_id>0)
		{
		        $jozeeat ="صورت فاکتور";
			$out = "<u><span style=\"color:Red;cursor:pointer;\" onclick=\"wopen('anbar_det.php?anbar_typ_id=".$_REQUEST['anbar_typ_id']."&anbar_factor_id=$inp&','',900,300);\">$jozeeat</span></u>";
			mysql_class::ex_sql("select `en` from `anbar_det` where `anbar_factor_id`='$inp'",$q);
	                while($r = mysql_fetch_array($q))
			{
				if ($r["en"]!=0)	
				{
					$out = "<u><span style=\"color:Blue;cursor:pointer;\" onclick=\"wopen('anbar_det.php?anbar_typ_id=".$_REQUEST['anbar_typ_id']."&anbar_factor_id=$inp&','',900,300);\">$jozeeat</span></u>";
				}
			}
		}
		else
			$out = '<span style="color:#999;">صورت فاکتور</span>';
                return $out;
        }
	function loadPrint($inp)
	{
		$out = "<span style=\"color:green;cursor:pointer;\" onclick=\"wopen('anbar_print.php?id=$inp&','',900,300);\"><u>چاپ</u></span>";
		return $out;
	}
	if(isset($_REQUEST['anbar_typ_id']) && $_REQUEST['anbar_typ_id']>0)
	{
		$anbar_type = new anbar_typ_class($_REQUEST['anbar_typ_id']);
		$msg = ' رسید ' .$anbar_type->name;
	}
	if(isset($_REQUEST['sel_id']))
        {
		$sel_id = $_REQUEST['sel_id'];
		if (isset($_REQUEST['moeen_id']))
	        {
        	        $moeen_id = (int)$_REQUEST['moeen_id'];
	                mysql_class::ex_sqlx("update `anbar_factor` set `moeen_id`=$moeen_id where `id`=$sel_id");
	        }
        	else
	        {
        	        $moeen_id = -1;
	        }
        }
	else
	{
		$sel_id = -1;
	}
	function hamed_pdateBack($inp)
        {
		$inp = perToEnNums($inp);
                $out = FALSE;
                $tmp = explode("/",$inp);
                if (count($tmp)==3)
                {
			$y=(int)$tmp[2];
			$m=(int)$tmp[1];
			$d=(int)$tmp[0];
			if ($d>$y)
			{
				$tmp=$y;
				$y=$d;
				$d=$tmp;
			}
			if ($y<1000)
			{
				$y=$y+1300;
			}
			$inp="$y/$m/$d";
                        $out = audit_class::hamed_jalalitomiladi(audit_class::perToEn($inp));
                }

                return $out;
        }
	$anbar_typ_id = (isset($_REQUEST['anbar_typ_id']))?(int)$_REQUEST['anbar_typ_id']:-1;
	$aztarikh = (isset($_REQUEST['aztarikh']))?audit_class::hamed_pdateBack($_REQUEST['aztarikh'])." 00:00:00":date("Y-m-d 00:00:00");
	$tatarikh = (isset($_REQUEST['tatarikh']))?audit_class::hamed_pdateBack($_REQUEST['tatarikh'])." 23:59:59":date("Y-m-d 23:59:59");
	$grid = new jshowGrid_new("anbar_factor","grid1");
	$grid->whereClause="`anbar_typ_id`=$anbar_typ_id and `tarikh_resid`>='$aztarikh' and `tarikh_resid`<='$tatarikh' order by `id` desc";
	$grid->width ='95%';
	$grid->index_width = '20px';
	$grid->columnHeaders[0] = "کد فاکتور";
	if((int)$anbar_type->typ==1)
	{
		$grid->columnHeaders[2] = 'نام فروشنده';
		$grid->columnHeaders[1] = 'شماره فاکتور فروشنده';
	}
	else if((int)$anbar_type->typ==-1)
	{
		$grid->columnHeaders[2] = 'نام خریدار';
		$grid->columnHeaders[1] = null;
	}
        $grid->columnHeaders[3] = 'توضیحات';
	$grid->columnHeaders[4] = 'حساب معین';
	$grid->columnLists[4]=loadMoeen();
	//$grid->enableComboAjax[4] = TRUE;
	$grid->list2 = TRUE;
	$grid->columnHeaders[5] = 'تاریخ صدور رسید';
	$grid->columnFunctions[5] = "hpdate";
        $grid->columnCallBackFunctions[5] = 'hpdateback';
	$grid->columnHeaders[6] = null;
	$grid->columnHeaders[7] = 'ثبت کننده';
	$grid->columnFunctions[7]='loadUser';
	$grid->columnAccesses[7] = 0;
	//$grid->addFeild('id');
	//$grid->columnHeaders[8] = "حساب معین";
	//$grid->columnFunctions[8]='loadMoeen';
	$grid->addFeild('id');
        $grid->columnHeaders[8] = 'صورت فاکتور';
        $grid->columnFunctions[8]='loadDet';
	$grid->addFeild('id');
        $grid->columnHeaders[9] = 'رسید/حواله';
        $grid->columnFunctions[9]='loadPrint';
	$grid->addFunction = 'add_item';
	$grid->columnAccesses[0] = 0;
	$grid->showAddDefault = FALSE;
        $grid->intial();
   	$grid->executeQuery();
        $out = $grid->getGrid();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link type="text/css" href="../css/style.css" rel="stylesheet" />

		<link type="text/css" href="../js/styles/jquery-ui-1.8.14.css" rel="stylesheet" />
		<script type="text/javascript" src="../js/jquery/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="../js/jquery/jquery.ui.datepicker-cc.all.min.js"></script>
		<script type="text/javascript" src="../js/tavanir.js"></script>
		<script type="text/javascript">
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#aztarikh").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#tatarikh").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
	    	</script>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>
		</title>
	</head>
	<body>
                <?php echo security_class::blockIfBlocked($se,lang_fa_class::block); ?>
		<div align="right" style="padding-right:30px;padding-top:10px;">
			<a href="help.php" target="_blank"><img src="../img/help.png"/></a>
		</div>
		<div align="center">
			<br/>
			<br/>
			<?php echo '<h2>'.$msg.'</h2>'; ?>
			<form id="frm1" >
از تاریخ:
				<input type="text" name="aztarikh" id="aztarikh" value="<?php echo (isset($_REQUEST['aztarikh']))?($_REQUEST['aztarikh']):audit_class::hamed_pdate((date('Y-m-d'))); ?>" class="inp" />
تا تاریخ:
				<input type="text" name="tatarikh" id="tatarikh" value="<?php echo (isset($_REQUEST['tatarikh']))?($_REQUEST['tatarikh']):audit_class::hamed_pdate((date('Y-m-d'))); ?>" class="inp" />
				<input type="hidden" name="anbar_typ_id" id="anbar_typ_id" value="<?php echo $anbar_typ_id; ?>" class="inp" />
				<input type="button" value="جستجو" class="inp" onclick="document.getElementById('frm1').submit();" />
			</form>
			<?php	
				echo $out;
			?>
		</div>
		<script language="javascript" >
			if(document.getElementById('new_user_id'))
				document.getElementById('new_user_id').style.display = 'none';
			var inps = document.getElementsByTagName('input');
			var element;
			for(var i=0;i<inps.length;i++)
			{
				element = inps[i].id.split('_');
				if(element[0]=='new' && element[1]=='id')
					inps[i].style.display = 'none';
			}
		</script>
	</body>
</html>
