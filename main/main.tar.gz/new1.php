<html>
        <head>
</head>
      <body>
<?php
	$today = strtotime(date("H:i:s"));
	$sumDate = strtotime("900");
	echo $today;
	echo "<br/>".timetostr($today);
?>
 </body>
</html>

