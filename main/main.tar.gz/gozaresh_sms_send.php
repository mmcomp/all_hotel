<?php
	session_start();
	include("../kernel.php");
        if(!isset($_SESSION['user_id']))
                die(lang_fa_class::access_deny);
        $se = security_class::auth((int)$_SESSION['user_id']);
        if(!$se->can_view)
                die(lang_fa_class::access_deny);
	function  loadHotel($inp=-1)
	{
		$inp = (int)$inp;
		$hotelList=daftar_class::hotelList((int)$_SESSION['daftar_id']);
		$shart = '';
		if($hotelList)
			$shart=' and ( `id`='.implode(" or `id`=",$hotelList).")";
		$out = '<select name="hotel_id" id="hotel_id" class="inp" style="width:auto;" ><option value="-1">همه</option>';
		mysql_class::ex_sql("select `id`,`name` from `hotel` where `moeen_id` > 0 $shart order by `name` ",$q);
		while($r = mysql_fetch_array($q))
		{
			$sel = (($r['id']==$inp)?'selected="selected"':'');
			$out.="<option $sel  value='".$r['id']."' >".$r['name']."</option>\n";
		}
		$out.='</select>';
		return $out;
	}
	function loadTyp_se($typ)
	{
		$out = "";
		mysql_class::ex_sql("select `id`,`typ` from `sms_typ`",$q);
		while($r = mysql_fetch_array($q))
		{			
			$typ_1 = $r['typ'];
			$id = $r['id'];
			$sel = (($r['id']==$typ)?'selected="selected"':'');
			$out .="<option value='$id' $sel >$typ_1</option>\n";
		}
		return $out;
	}
	function hamed_pdate($str)
        {
                $out=jdate('Y/n/j',strtotime($str));
                return $out;
        }
	function loadStat($inp)
	{
		$out = "";
		if ($inp==1)
			$out = 'ارسال موفقیت آمیز';
		else
			$out = 'ارسال نشده';
		return $out;
	}
	function loadTyp($inp)
	{
		$out = "";
		mysql_class::ex_sql("select `id`,`typ` from `sms_typ` where `id`='$inp'",$q);
		if($r = mysql_fetch_array($q))
			$out = $r['typ'];
		return $out;
	}
	$hotel_id = (isset($_REQUEST['hotel_id']))?(int)$_REQUEST['hotel_id']:-1;
	$typ = (isset($_REQUEST['typ']))?(int)$_REQUEST['typ']:-1;
	$aztarikh = ((isset($_REQUEST['aztarikh']))?audit_class::hamed_pdateBack($_REQUEST['aztarikh']):date('Y-m-d H:i:s'));
	$tatarikh = ((isset($_REQUEST['tatarikh']))?audit_class::hamed_pdateBack($_REQUEST['tatarikh']):date('Y-m-d H:i:s'));
	$aztarikh = date("Y-m-d 00:00:00",strtotime($aztarikh));
	$tatarikh = date("Y-m-d 23:59:59",strtotime($tatarikh));
	mysql_class::ex_sql("select `reserve_id`,`room_id` from `room_det` where `aztarikh`>='$aztarikh' and `tatarikh`<='$tatarikh'",$q);
	$res = '';
	while($r = mysql_fetch_array($q))
	{
		$r_id = $r['room_id'];
		mysql_class::ex_sql("select `hotel_id` from `room` where `id`='$r_id'",$q_room);
		if($r_room = mysql_fetch_array($q_room))
		{
			if ($hotel_id!=-1)
			{
				if (($r_room['hotel_id']==$hotel_id)&&($r['reserve_id']>0))
					$res .=($res==''? '':',' ).$r['reserve_id'];
			}
			else
			{
				if ($r['reserve_id']>0)
					$res .=($res==''? '':',' ).$r['reserve_id'];
			}
		}
	}
	if ($res!='')
		$shart = "`reserve_id` in ($res) and `sms_typ`='$typ'";
	else
		$shart = '1=0';
	$grid = new jshowGrid_new("sms_send","grid1");
	$grid->whereClause = " $shart order by `reserve_id`";
//echo ($grid->whereClause);
	$grid->columnHeaders[0]= null;
	$grid->columnHeaders[1]= 'شماره رزرو';
	$grid->columnHeaders[2]= 'متن پیامک';
	$grid->columnHeaders[3]= 'وضعیت ارسال';
	$grid->columnFunctions[3]= 'loadStat';
	$grid->columnHeaders[4]= 'نوع پیامک';
	$grid->columnFunctions[4]= 'loadTyp';
	$grid->columnHeaders[5]= 'تاریخ ارسال';
	$grid->columnFunctions[5]= 'hamed_pdate';
	$grid->columnHeaders[6]= 'تعداد مرتبه ارسال';
	$grid->canAdd = FALSE;
	$grid->canDelete = FALSE;
	$grid->canEdit = FALSE;
	$grid->intial();
	$grid->executeQuery();
	$out = $grid->getGrid();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link type="text/css" href="../css/style.css" rel="stylesheet" />

		<link type="text/css" href="../js/styles/jquery-ui-1.8.14.css" rel="stylesheet" />
		<script type="text/javascript" src="../js/jquery/jquery-1.6.2.min.js"></script>
		<script type="text/javascript" src="../js/jquery/jquery.ui.datepicker-cc.all.min.js"></script>
		<script type="text/javascript" src="../js/tavanir.js"></script>
		<script>
			$(document).ready(function(){
//				$("#new_regdate").hide();
//				$("#new_answer").hide();
//				$("#new_isFixed").hide();
			});
		</script>
		<style>
			td{text-align:center;}
		</style>
		<title>
پیامک های ارسال شده
		</title>
		<script type="text/javascript">
		    function send_search()
		    {
			document.getElementById('mod').value= 2;
			document.getElementById('frm1').submit();
		    }
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#datepicker6").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
		    $(function() {
			//-----------------------------------
			// انتخاب با کلیک بر روی عکس
			$("#datepicker7").datepicker({
			    showOn: 'button',
			    dateFormat: 'yy/mm/dd',
			    buttonImage: '../js/styles/images/calendar.png',
			    buttonImageOnly: true
			});
		    });
	    	</script>
	</head>
	<body>
		<br/>
		<br/>
                <?php echo security_class::blockIfBlocked($se,lang_fa_class::block); ?>
		<div align="center">
			<div align="center">
			<br/>
			<br/>
			<form id='frm1'  method='GET' >
			<table border='1' style='font-size:12px;width:95%;' >
				<tr>
					<th>نام هتل</th>
					<th>نوع</th>
					<th>از تاریخ</th>
					<th>تا تاریخ</th>
					<th>جستجو</th>
				</tr>
				<tr valign="bottom" >
					<td>	
						<?php echo loadHotel($hotel_id); ?>
					</td>
					<td>
						<select class="inp" name="typ" id="typ" >
							<?php echo loadTyp_se($typ); ?>	
						</select>	
					</td>
					<td>	
         					   <input value="<?php echo ((isset($_REQUEST['aztarikh']))?$_REQUEST['aztarikh']:''); ?>" type="text" name='aztarikh' readonly='readonly' class='inp' style='direction:ltr;' id="datepicker6" />	
					</td>
					<td>
						<input value="<?php echo ((isset($_REQUEST['tatarikh']))?$_REQUEST['tatarikh']:''); ?>" type="text" name='tatarikh' readonly='readonly' class='inp' style='direction:ltr;' id="datepicker7" />
					</td>
					<td>
						<input type='hidden' name='mod' id='mod' value='1' >
						<input type='button' value='جستجو' class='inp' onclick='send_search();' >
					</td>					
				</tr>
			</table>
			</form>
			<br/>
		</div>
			<?php echo $out; ?>
		</div>
	</body>
</html>
