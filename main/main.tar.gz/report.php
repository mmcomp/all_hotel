<?php	session_start();
	include_once("../kernel.php");
	function pdate1($inp)
	{
		return(audit_class::hamed_pdate($inp));
	}
	function bedBes($inp)
	{
		return(((int)$inp == -1)?'بدهکار':'بستانکار');
	}
	$GLOBALS['msg'] = '';
	$out = '';
	$req = ((isset($_REQUEST['req']))?$_REQUEST['req']:'');
	$room_id = ((isset($_REQUEST['room_id']))?$_REQUEST['room_id']:'');
	if($req != '')
	{
		$reserve_id = (int)$req;
		$reserve = new reserve_class($reserve_id);
		if($reserve->id>0)
		{
			$GLOBALS['msg'] = '<h2>آقا/خانم '.$reserve->hotel_reserve->fname.' '.$reserve->hotel_reserve->lname.' اطلاعات مالی یافت نشد.</h2>';
			$room_shart = '';
			//for($i = 0;$i < count($reserve->room_det);$i++)
			//{
				//$room_tmp = new room_class($reserve->room_det[$i]->room_id);
			$room_tmp = new room_class($room_id);
			$moeen_id = $room_tmp->moeen_id;
			if($moeen_id>0)
			{
				$aztarikh = date("Y-m-d",strtotime($reserve->room_det[0]->aztarikh));
				$tatarikh = date("Y-m-d",strtotime($reserve->room_det[0]->tatarikh));
				$room_shart .="( `moeen_id` = $moeen_id and DATE(`tarikh`)>='$aztarikh' and DATE(`tarikh`) <= '$tatarikh' )";
			}
			//}
			if($room_shart == '')
				$room_shart = '1=0';
			$q = null;
			mysql_class::ex_sql("select SUM(`mablagh`*`typ`) as `jam` from `sanad` where $room_shart",$q);
			if($r = mysql_fetch_array($q))
				$jam_kol = (int)$r['jam'];
			$grid = new jshowGrid_new("sanad","grid1");
			$grid->setERequest(array('req'=>$req));
			$grid->whereClause = " $room_shart";
			$grid->columnHeaders[0] = null;
			$grid->columnHeaders[1] = null;
			$grid->columnHeaders[2] = null;
			$grid->columnHeaders[3] = null;
			$grid->columnHeaders[4] = null;
			$grid->columnHeaders[5] = null;
			$grid->columnHeaders[6] = null;
			$grid->columnHeaders[7] = null;
			$grid->columnHeaders[8] = null;
			$grid->columnHeaders[9] = 'تاریخ';
			$grid->columnHeaders[10] = null;
			$grid->columnHeaders[11] = 'بدهکار/بستانکار';
			$grid->columnHeaders[12] = 'توضیحات';
			$grid->columnHeaders[13] = null;
			$grid->columnHeaders[14] = 'مبلغ';
			$grid->columnFunctions[9] = 'pdate1';
			$grid->columnFunctions[11] = 'bedBes';
			$grid->columnFunctions[14] = 'monize';
			$grid->sortEnabled = TRUE;
			$grid->canAdd = FALSE;
			$grid->canEdit = FALSE;
			$grid->canDelete = FALSE;
			$grid->intial();
			$grid->executeQuery();
			$out = $grid->getGrid();
			$GLOBALS['msg'] = '<h2>آقا/خانم '.$reserve->hotel_reserve->fname.' '.$reserve->hotel_reserve->lname.' جمع حساب شما : '.monize(abs($jam_kol)).' ریال '.(($jam_kol>0)?' بستانکار':' بدهکار').'</h2>';
		}
		else
			$GLOBALS['msg'] = 'کد مشتری صحیح نمی باشد.';
	}
	else
		die($conf->access_deny);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<!-- Style Includes -->
		<link type="text/css" href="../js/jquery/themes/trontastic/jquery-ui.css" rel="stylesheet" />
		<link type="text/css" href="../js/jquery/window/css/jquery.window.css" rel="stylesheet" />

		<link type="text/css" href="../css/style.css" rel="stylesheet" />

		<!-- JavaScript Includes -->
		<script type="text/javascript" src="../js/jquery/jquery.js"></script>

		<script type="text/javascript" src="../js/jquery/jquery-ui.js"></script>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>
		</title>
	</head>
	<body>
		<div align="right" style="padding-right:30px;padding-top:10px;">
			<a href="help.php" target="_blank"><img src="../img/help.png"/></a>
		</div>
		<div align="center">
			<br/>
			<!--
			<form id="frm1">
				کد مشتری خود را وارد کنید : <input type="text" id="req" name="req" value="<?php echo $req; ?>" />
				<input type="submit" value="انتخاب" class='inp'/>
			</form>
			-->
			<br/>
			<?php	echo $GLOBALS['msg'].'<br/>'.$out;?>
		</div>
	</body>

</html>
