<?php
	include('../kernel.php');
	log_class::add("resreve2",1233,'asdsfdf');
?>
