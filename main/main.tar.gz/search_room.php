<?php
	include_once("../kernel.php");
	var_dump(room_class::loadOpenRooms("2011-10-29 00:00:00",4,11));
?>
